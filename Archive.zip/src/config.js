const BASE_URL = 'https://gorest.co.in/public/v2';

export default BASE_URL;