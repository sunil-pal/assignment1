import React, { useState, lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

const Login = lazy(() => import('./pages/Login'));
const Signup = lazy(() => import('./pages/Signup'));
const Home = lazy(() => import('./pages/Home'));
const About = lazy(() => import('./pages/About'));
const Contact = lazy(() => import('./pages/Contact'));
const NotFound = lazy(() => import('./pages/NotFound'));

const App = () => {
  const [isLoggedIn, setLoggedIn] = useState(!!localStorage.getItem('isLoggedIn'));

  return (
    <Router>
      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          <Route path="/" element={isLoggedIn ? <Navigate to="/home" /> : <Login setLoggedIn={setLoggedIn} />} />
          <Route path="/home" element={isLoggedIn ? <Home setLoggedIn={setLoggedIn} /> : <Navigate to="/" />} />
          <Route path="/signup" element={isLoggedIn ? <Home setLoggedIn={setLoggedIn} /> :<Signup setLoggedIn={setLoggedIn} />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
    </Router>
  );
};

export default App;