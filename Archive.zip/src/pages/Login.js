import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import FormInput from '../components/common/FormInput'
import FormButton from '../components/common/FormButton';
import '../styles/Common.css';

const Login = ({ setLoggedIn }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const users = useSelector((state) => state.users);
  const navigate = useNavigate();

  const handleLogin = () => {
    // Simple fake login validation
    const user = users.find((user) => user.email === email && user.password === password);
    if (user) {
      // Set isLoggedIn flag to true in local storage
      localStorage.setItem('isLoggedIn', 'true');
      setLoggedIn(true);
    } else {
      setError('Invalid credentials. Please try again.');
    }
  };

  const clearError = () => {
    setError('');
  };

  return (
    <div className="block-container">
      <h2 className="block-header">Login</h2>
      {error && <div className="error-message" onClick={clearError}>{error}</div>}
        <FormInput
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email"
          className={error && !email ? 'invalid' : ''}
        />
        <FormInput
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          className={error && !password ? 'invalid' : ''}
        />
        <FormButton onClick={handleLogin} disabled={!email || !password} label="Login" />
        <div className="signup-link">
          Don't have an account? <span onClick={() => navigate('/signup')}>Sign up</span>
        </div>
    </div>
  );
};

export default Login;