// ContactPage.js
import React from 'react';
import '../styles/Contact.css'; // Import the CSS file for this page

const ContactPage = () => {
  return (
    <div className="contact-page-container">
      <h1>Contact Us</h1>
      <div className="contact-info">
        <p>
          <strong>Email:</strong> contact@example.com
        </p>
        <p>
          <strong>Address:</strong> 123 Main Street, City, Country
        </p>
        <p>
          <strong>Contact:</strong> +1 123-456-7890
        </p>
      </div>
    </div>
  );
};

export default ContactPage;
