import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Home.css';
import UserTable from '../components/UserTable';

const Home = ({ setLoggedIn }) => {
  const handleLogout = () => {
    // Clear the user's authentication status
    localStorage.removeItem('isLoggedIn');
    setLoggedIn(false);
  };

  return (
    <div className="home-container">
      <header className="header">
        <h1>My Awesome App</h1>
        <nav>
          <Link to="/home">Home</Link>
          <Link to="/about">About</Link>
          <Link to="/contact">Contact</Link>
          <button onClick={handleLogout}>Logout</button>
        </nav>
      </header>
      <main className="main-content">
        <h2>Welcome to My Awesome App!</h2>
        
        <UserTable />
      </main>
      <footer className="footer">
        <p>&copy; {new Date().getFullYear()} My Awesome App. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default Home;