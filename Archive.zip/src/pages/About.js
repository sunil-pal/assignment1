import React from 'react';
import '../styles/About.css';

const AboutUs = () => {
  return (
    <div className="about-us-container">
      <h1>About Us</h1>
      <img
        src="https://via.placeholder.com/300"
        alt="Company Logo"
        className="logo"
      />
      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eu justo at
        felis ullamcorper egestas et eu massa. Sed vitae gravida mi, quis
        consectetur quam. In vestibulum velit sapien, nec consequat lorem
        scelerisque at. Phasellus porttitor venenatis nunc, ut ultrices elit
        gravida quis. Duis nec consectetur elit.
      </p>
      <p>
        Nulla vitae elementum elit, quis auctor risus. Cras efficitur turpis
        sit amet dolor tempus, nec volutpat tortor iaculis. Nullam commodo
        massa nec dolor dignissim scelerisque. Nullam in felis quis purus
        tincidunt iaculis. Vestibulum vehicula nisi non nunc hendrerit, a
        interdum nibh fermentum.
      </p>
    </div>
  );
};

export default AboutUs;
