import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import validator from 'validator';
import FormInput from '../components/common/FormInput';
import FormButton from '../components/common/FormButton';
import '../styles/Common.css';
import { addUser } from '../redux/userSlice';

const Signup = ({ setLoggedIn }) => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const handleSignup = () => {
        // Simple fake signup validation
        if (validator.isEmpty(name) || !validator.isEmail(email) || validator.isEmpty(password) || password !== confirmPassword) {
            setError('Invalid input. Please fill in all fields correctly.');
            return;
        }

        // Save data in Redux state
        dispatch(addUser({ name, email, password }));

        // Set isLoggedIn flag to true in local storage and state
        localStorage.setItem('isLoggedIn', 'true');
        setLoggedIn(true);

        // Redirect to home page after successful signup
        navigate('/home');
    };

    // Function to check if all input fields are filled
    const areAllFieldsFilled = () => {
        return name.trim() !== '' && email.trim() !== '' && validator.isEmail(email) && password.trim() !== '' && confirmPassword.trim() !== '';
    };

    // Function to clear the error message
    const clearError = () => {
        setError('');
    };

    return (
        <div className="block-container">
            <h2 className="block-header">Signup</h2>
            {error && <div className="error-message" onClick={clearError}>{error}</div>}
            <FormInput
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Name"
                className={error && !name ? 'invalid' : ''}
            />
            <FormInput
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
                className={error && !validator.isEmail(email) ? 'invalid' : ''}
            />
            <FormInput
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                className={error && !password ? 'invalid' : ''}
            />
            <FormInput
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm Password"
                className={error && (password !== confirmPassword) ? 'invalid' : ''}
            />
            <FormButton onClick={handleSignup} disabled={!areAllFieldsFilled()} label="Signup" />
        </div>
    );
};

export default Signup;