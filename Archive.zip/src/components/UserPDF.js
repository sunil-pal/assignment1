import React from 'react';
import { Document, Page, Text, View, StyleSheet } from '@react-pdf/renderer';

const styles = StyleSheet.create({
  page: {
    flexDirection: 'column',
    alignItems: 'center',
    fontFamily: 'Helvetica',
    paddingTop: 30,
    paddingBottom: 60,
    paddingHorizontal: 30,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    textAlign: 'center',
    textDecoration: 'underline',
  },
  table: {
    display: 'table',
    width: '100%',
    borderStyle: 'solid',
    borderWidth: 1,
    borderColor: '#000',
  },
  tableRow: {
    flexDirection: 'row',
  },
  tableHeader: {
    backgroundColor: '#f0f0f0',
    borderBottomWidth: 1,
  },
  tableCell: {
    flex: 1,
    padding: 5,
    borderStyle: 'solid',
    borderWidth: 1,
    borderColor: '#000',
    textAlign: 'center',
  },
});

const UserPDF = ({ users }) => {
  return (
    <Document>
      <Page style={styles.page}>
        <Text style={styles.title}>User Data</Text>
        <View style={styles.table}>
          {/* Table Header */}
          <View style={styles.tableRow}>
            <View style={[styles.tableCell, styles.tableHeader]}>
              <Text>Name</Text>
            </View>
            <View style={[styles.tableCell, styles.tableHeader]}>
              <Text>Email</Text>
            </View>
            <View style={[styles.tableCell, styles.tableHeader]}>
              <Text>Gender</Text>
            </View>
            <View style={[styles.tableCell, styles.tableHeader]}>
              <Text>Status</Text>
            </View>
          </View>

          {/* Table Rows */}
          {users.map((user) => (
            <View style={styles.tableRow} key={user.id}>
              <View style={styles.tableCell}>
                <Text>{user.name}</Text>
              </View>
              <View style={styles.tableCell}>
                <Text>{user.email}</Text>
              </View>
              <View style={styles.tableCell}>
                <Text>{user.gender}</Text>
              </View>
              <View style={styles.tableCell}>
                <Text>{user.status}</Text>
              </View>
            </View>
          ))}
        </View>
      </Page>
    </Document>
  );
};

export default UserPDF;