import React, { useEffect, useState } from 'react';
import axios from 'axios';
import BASE_URL from '../config';
import Modal from 'react-modal';
import validator from 'validator';
import { PDFDownloadLink } from '@react-pdf/renderer';
import UserPDF from './UserPDF';

const UserTable = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isLoadingApi, setLoadingApi] = useState(false);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    gender: '',
    status: '',
  });

  useEffect(() => {
    // Fetch user data from the API
    axios
      .get('/users', {
        baseURL: BASE_URL,
        headers: {
          'Authorization': 'Bearer b570480fdd257112e2a35414dc1ea4321894d039e061e965a6f361fc360ad979',
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      })
      .then((response) => {
        setUsers(response.data); // Update the state with user data
        setLoading(false); // Data loading is complete
      })
      .catch((error) => {
        console.error('Error fetching user data:', error);
        setLoading(false); // Data loading is complete even if there's an error
      });
  }, []);

  const handleAddUserClick = () => {
    setModalIsOpen(true);
    setSelectedUser(null);
    // Clear the form data when adding a new user
    setFormData({
      name: '',
      email: '',
      gender: '',
      status: '',
    });
  };

  const handleUpdateUserClick = (user) => {
    setModalIsOpen(true);
    setSelectedUser(user);
    // Set the form data with the selected user's data when updating
    setFormData({
      name: user.name,
      email: user.email,
      gender: user.gender,
      status: user.status,
    });
  };

  const handleModalClose = () => {
    setModalIsOpen(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();

    // Basic validation for required fields (name, email, gender, status)
    if (!formData.name.trim() || !formData.email.trim() || !formData.gender.trim() || !formData.status.trim()) {
      alert('All fields are required.');
      return;
    }

    // Validate email format using validator.isEmail()
    if (!validator.isEmail(formData.email)) {
      alert('Invalid email format.');
      return;
    }

    try {
      setLoadingApi(true);

      if (selectedUser) {
        // If selectedUser is present, we are updating an existing user using the PUT method
        axios
          .put(`/users/${selectedUser.id}`, formData, {
            baseURL: BASE_URL,
            headers: {
              'Authorization': 'Bearer b570480fdd257112e2a35414dc1ea4321894d039e061e965a6f361fc360ad979',
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
          })
          .then((response) => {
            // Update the user data in the state with the updated response
            const updatedUsers = users.map((user) =>
              user.id === selectedUser.id ? response.data : user
            );
            setUsers(updatedUsers);
          })
          .catch((error) => {
            console.error('Error updating user data:', error);
          });
      } else {
        // If selectedUser is null, we are adding a new user using the POST method
        axios
          .post('/users', formData, {
            baseURL: BASE_URL,
            headers: {
              'Authorization': 'Bearer b570480fdd257112e2a35414dc1ea4321894d039e061e965a6f361fc360ad979',
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
          })
          .then((response) => {
            // Add the new user to the user data in the state
            setUsers([...users, response.data]);
          })
          .catch((error) => {
            console.error('Error adding new user:', error);
          });
      }

      handleModalClose();
    } catch (error) {
      console.error('Error occurred while adding/updating user:', error);
    } finally {
      setLoadingApi(false);
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h2 className='table-heading'>User Module</h2>
      <PDFDownloadLink
        document={<UserPDF users={users} />} // Updated component name
        fileName="user_data.pdf"
      >
        {({ blob, url, loading, error }) =>
          loading ? 'Loading PDF...' : 'PDF Export'
        }
      </PDFDownloadLink>
      <button className='add-user' onClick={handleAddUserClick}>+ Add User</button>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Gender</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.id}>
              <td>{user.name}</td>
              <td>{user.email}</td>
              <td>{user.gender}</td>
              <td>{user.status}</td>
              <td>
                <button onClick={() => handleUpdateUserClick(user)}>Update</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <Modal
        isOpen={modalIsOpen}
        onRequestClose={handleModalClose}
      >
        {selectedUser ? <h2>Update User</h2> : <h2>Add User</h2>}
        <form onSubmit={handleFormSubmit}>
          <div>
            <label htmlFor="name">Name:</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
            />
          </div>
          <div>
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
            />
          </div>
          <div>
            <label htmlFor="gender">Gender:</label>
            <input
              type="text"
              id="gender"
              name="gender"
              value={formData.gender}
              onChange={handleInputChange}
            />
          </div>
          <div>
            <label htmlFor="status">Status:</label>
            <input
              type="text"
              id="status"
              name="status"
              value={formData.status}
              onChange={handleInputChange}
            />
          </div>
          <div className='footer-action'>
            <button onClick={handleModalClose}>Close Modal</button>
            <button type="submit">{isLoadingApi ? 'Loading...' : (selectedUser ? 'Update User' : 'Add User')}</button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default UserTable;